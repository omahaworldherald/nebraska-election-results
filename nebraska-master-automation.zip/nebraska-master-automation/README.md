# Nebraska election feeds — GitHub Actions prototype

Source: https://electionresults.nebraska.gov/resultsCSV.aspx?text=All&type=All&map=CTY

## Setup

1. Create a **public** GitHub repository and upload `update.py` and `.github/workflows/update.yml` to the default branch.
2. In **Settings → Actions → General → Workflow permissions**, allow **Read and write permissions** for `GITHUB_TOKEN`. Organization policy may restrict this.
3. Open **Actions → Update Nebraska election feeds → Run workflow**. Check logs and confirm `public/feeds/congress.csv`, `public/feeds/races/*.csv`, `public/feeds/race_index.csv`, `public/feeds/senate.csv` and `public/feeds/governor.csv` were committed.
4. For the initial test, use the public raw CSV URL `https://raw.githubusercontent.com/OWNER/REPO/main/public/feeds/congress.csv` (replace OWNER, REPO, and main if your default branch differs). Check whether Datawrapper accepts it and refreshes reliably. GitHub Pages branch publishing does not offer `/public` as a selectable folder; hosting on Pages would require a separate deployment workflow or moving files to `/docs`.
5. In Datawrapper, select **Link external dataset** for the choropleth and enter that URL. Map `district` to the district identifiers. Color using `rep_pct`, `dem_pct`, etc. Keep `_votes` fields for tooltips.
6. Test with a changed fixture before election night. GitHub scheduled jobs can be delayed or dropped and are not guaranteed to execute every five minutes.

## Local test

```bash
python update.py --input sample-master.csv --output public
```

## Output

- `public/feeds/congress.csv`: one row per congressional district; party vote totals and percentages; `has_results` field.
- `public/feeds/races/<RaceID>.csv`: candidate-level results for each race.
- `public/feeds/race_index.csv`: lookup table for race IDs and names.
- `public/feeds/senate.csv`, `public/feeds/governor.csv`: candidate-level convenience feeds.
- `public/snapshots/<hash>.csv`: exact original source bytes for each distinct downloaded version.
- `public/status.json`: source digest, timestamp and counts.

## Critical limitations

- This export appears to provide **contest totals**, not county-level results. `map=CTY` in the URL does not prove county-granular rows are present. Validate separately before making county choropleths.
- `PET` and unknown party codes are retained as original `party_code` in candidate-level feeds but grouped as `OTH` in wide map feeds. Do not silently label petition candidates independent.
- `has_results=no` means a party's zero percentage must **not** be interpreted as actual 0% support. Configure no-results styling or use a filtered feed for election-night publishing.
- Percentages are calculated from all candidate votes in the race, not the source `CandidatePercentage`. Source percentage may have different semantics in vote-for-multiple races.
- `congress.csv` has one row per congressional district and is intended for **party-share maps**. It is not a leading-party color map.
- A public repo exposes snapshots and all feeds. Do not put secrets, API tokens, or confidential data in it.
- `snapshots` can grow over election night; consider Git LFS/object storage or pruning for a long-term archive.
- The process currently validates columns and nonnegative vote counts but not all newsroom quality controls. Add alerts, stale-source detection, anomaly checks, tie handling, election-specific namespaces, and an editorial publication switch before production.
- For long-term historical data, create a new repository or output prefix for each election to prevent overwriting current results and to keep IDs scoped by election.
